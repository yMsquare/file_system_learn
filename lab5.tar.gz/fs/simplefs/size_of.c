#include <stdio.h>
#include <stdint.h>

int main() {
    printf("Size of uint32_t: %zu bytes\n", sizeof(uint32_t));
    return 0;
}